---
name: Documentation
about: Changes to markdown (.md) files
title: ''
labels: documentation
assignees: ''
---

<!-- Write a summary to provide context to the reviewer -->
This is needed because...

---

Closes #ISSUE_ID
