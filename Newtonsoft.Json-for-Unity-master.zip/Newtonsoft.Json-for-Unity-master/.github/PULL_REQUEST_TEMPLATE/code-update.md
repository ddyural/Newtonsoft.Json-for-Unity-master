---
name: Code changes
about: Changes to markdown (.md) files
title: ''
labels: enhancement
assignees: ''
---

<!-- Write a summary to provide context to the reviewer -->
This is needed because...

## Changes

- Added cupcakes
- Removed salt

## Preview

<!-- If applicable, include a screenshot -->

---

Closes #ISSUE_ID
